import UIKit

struct carFeature {
    var engineType = ""
    var carSize = ""
    var color = ""
    var model = ""
    
    func allFeature () -> String {
        return "I look for 4 features in car:" + "\n" + engineType + " " + carSize + " " + color + " " + model
    }
}

var onlyFeature = (engineType: "V6", carSize: "big", color: "black", model: "toyota")
onlyFeature.allfeature()

print(onlyFeature.allfeature())
